// Copyright (2013) Krishna C Tripathi. All rights reserved.
// 
// You are not allowed to read/copy/distribute following code without explicit written authorization from Krishna C Tripathi
//
package org.himalay.dhcpv6;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.lang.Exception;
import java.io.ByteArrayInputStream;
import java.io.PrintStream;
import org.himalay.msgs.runtime.Created;

import org.himalay.msgs.runtime.*;

@Created(date = "Thu Nov 06 01:18:25 EST 2014")
public class ClientId extends DhcpOptionFactory.DhcpOption { // Concrete type is
																// ClientId

	// members variables
	// header
	public DhcpOptionHeader header;
	// duid
	public DuidFactory.Duid duid;

	public ClientId() // throws Exception
	{
		init();
	}

	private void init() {
		// Initialize header
		header = new DhcpOptionHeader();
		// Initialize duid
		/* Generic classes are abstract, so we can not invoke new */
	}

	public int readNoHeader(DataInputStream istream) throws IOException {

		preRead();
		int retVal = 0;
		// read duid
		{
			IntegerHolder iHolder = new IntegerHolder();
			int iCount = getHeader().length;
			byte[] ba = new byte[iCount];
			istream.readFully(ba);
			DataInputStream disTemp = new DataInputStream(
					new ByteArrayInputStream(ba));
			duid = DuidFactory.createMsg(disTemp, iHolder);
			retVal += iHolder.getValue();
		}

		postRead();
		return retVal;
	}

	public int read(DataInputStream istream) throws IOException {
		preRead();
		int retVal = 0;

		// read header
		retVal += header.read(istream);
		// read duid
		{
			IntegerHolder iHolder = new IntegerHolder();
			int iCount = getHeader().length;
			byte[] ba = new byte[iCount];
			istream.readFully(ba);
			DataInputStream disTemp = new DataInputStream(
					new ByteArrayInputStream(ba));
			duid = DuidFactory.createMsg(disTemp, iHolder);
			retVal += iHolder.getValue();
		}

		postRead();
		return retVal;
	}

	public int write(DataOutputStream ostream) throws IOException {
		preWrite();
		int retVal = 0;

		{
			/** fix dependent sizes for header **/
		}
		{
			/** fix dependent sizes for duid **/
			if (duid != null)
				header.length = ((short) duid.getSize());
		}

		// write header
		if (header != null)
			retVal += header.write(ostream);
		// write duid
		if (duid != null)
			retVal += duid.write(ostream);
		postWrite();
		return retVal;
	}

	public int dump(DumpContext dc) throws IOException {
		dc.indent();
		dc.getPs().print("ClientId\n");
		dc.increaseIndent();
		int retVal = 0;
		// write header
		if (header != null) {
			dc.indent();
			dc.getPs().println("header");
			retVal += header.dump(dc);
		}
		// write duid
		if (duid != null) {
			dc.indent();
			dc.getPs().println("duid");
			retVal += duid.dump(dc);
		}
		dc.decreaseIndent();
		return retVal;
	}

	// Getter for header
	// public DhcpOptionHeader getHeader()
	// {
	// return header ;
	// }

	// Setter for header
	// public void setHeader(DhcpOptionHeader val)
	// {
	// this.header= val;
	// }
	// Getter for duid
	// public DuidFactory.Duid getDuid()
	// {
	// return duid ;
	// }

	// Setter for duid
	// public void setDuid(DuidFactory.Duid val)
	// {
	// this.duid= val;
	// }

	public int getSize() throws IOException {
		DataOutputStream dos = new DataOutputStream(new NullStream());
		return this.write(dos);
	}

	public void setHeader(DhcpOptionHeader header) {
		this.header = header;
	}

	public DhcpOptionHeader getHeader() {
		return this.header;
	}

}

// End of code