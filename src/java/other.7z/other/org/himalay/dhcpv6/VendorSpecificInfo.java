// Copyright (2013) Krishna C Tripathi. All rights reserved.
// 
// You are not allowed to read/copy/distribute following code without explicit written authorization from Krishna C Tripathi
//
package org.himalay.dhcpv6;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.lang.Exception;
import java.io.ByteArrayInputStream;
import java.io.PrintStream;
import org.himalay.msgs.runtime.Created;

import org.himalay.msgs.runtime.*;

@Created(date = "Thu Nov 06 01:18:25 EST 2014")
public class VendorSpecificInfo extends DhcpOptionFactory.DhcpOption { // Concrete
																		// type
																		// is
																		// VendorSpecificInfo

	// members variables
	// header
	public DhcpOptionHeader header;
	// enterprizeNum
	public long enterprizeNum;
	// options
	public ArrayList<DhcpOptionFactory.DhcpOption> options;

	public VendorSpecificInfo() // throws Exception
	{
		init();
	}

	private void init() {
		// Initialize header
		header = new DhcpOptionHeader();
		// Initialize enterprizeNum

		// Initialize options
		options = new ArrayList<DhcpOptionFactory.DhcpOption>();
		options.setMemberSize(0);
	}

	public int readNoHeader(DataInputStream istream) throws IOException {

		preRead();
		int retVal = 0;
		// read enterprizeNum
		{
			enterprizeNum = (long) (BinPrimitive.readUI32(istream));
			retVal += 4;
		}
		// read options
		{
			int ilimit = retVal + (getHeader().length + (-4));
			for (; retVal < ilimit;) {
				DhcpOptionFactory.DhcpOption temp; /*
													 * Generic classes are
													 * abstract, so we can not
													 * invoke new
													 */
				{
					IntegerHolder iHolder = new IntegerHolder();
					DataInputStream disTemp = istream;
					temp = DhcpOptionFactory.createMsg(disTemp, iHolder);
					retVal += iHolder.getValue();
				}
				options.add(temp);
			}
		}

		postRead();
		return retVal;
	}

	public int read(DataInputStream istream) throws IOException {
		preRead();
		int retVal = 0;

		// read header
		retVal += header.read(istream);
		// read enterprizeNum
		{
			enterprizeNum = (long) (BinPrimitive.readUI32(istream));
			retVal += 4;
		}
		// read options
		{
			int ilimit = retVal + (getHeader().length + (-4));
			for (; retVal < ilimit;) {
				DhcpOptionFactory.DhcpOption temp; /*
													 * Generic classes are
													 * abstract, so we can not
													 * invoke new
													 */
				{
					IntegerHolder iHolder = new IntegerHolder();
					DataInputStream disTemp = istream;
					temp = DhcpOptionFactory.createMsg(disTemp, iHolder);
					retVal += iHolder.getValue();
				}
				options.add(temp);
			}
		}

		postRead();
		return retVal;
	}

	public int write(DataOutputStream ostream) throws IOException {
		preWrite();
		int retVal = 0;

		{
			/** fix dependent sizes for header **/
		}

		{
			/** fix dependent sizes for options **/
			header.length = ((short) options.getSize() - (-4));
		}

		// write header
		if (header != null)
			retVal += header.write(ostream);
		// write enterprizeNum
		BinPrimitive.writeUI32(ostream, enterprizeNum);
		retVal += 4;
		// write options
		{
			ArrayList<DhcpOptionFactory.DhcpOption> temp1 = options;
			for (int iIdx = 0; iIdx < temp1.getCount(); iIdx++) {
				DhcpOptionFactory.DhcpOption temp2 = temp1.get(iIdx);
				if (temp2 != null)
					retVal += temp2.write(ostream);
			}
		}
		postWrite();
		return retVal;
	}

	public int dump(DumpContext dc) throws IOException {
		dc.indent();
		dc.getPs().print("VendorSpecificInfo\n");
		dc.increaseIndent();
		int retVal = 0;
		// write header
		if (header != null) {
			dc.indent();
			dc.getPs().println("header");
			retVal += header.dump(dc);
		}
		// write enterprizeNum
		dc.indent();
		dc.getPs().println(
				"enterprizeNum=" + enterprizeNum + "(0x"
						+ Long.toHexString(enterprizeNum) + ")");
		// write options
		{
			ArrayList<DhcpOptionFactory.DhcpOption> temp1 = options;
			for (int iIdx = 0; iIdx < temp1.getCount(); iIdx++) {
				DhcpOptionFactory.DhcpOption element = temp1.get(iIdx);
				dc.indent();
				dc.getPs().println(iIdx);
				if (element != null) {
					dc.indent();
					dc.getPs().println("element");
					retVal += element.dump(dc);
				}
			}
		}
		dc.decreaseIndent();
		return retVal;
	}

	// Getter for header
	// public DhcpOptionHeader getHeader()
	// {
	// return header ;
	// }

	// Setter for header
	// public void setHeader(DhcpOptionHeader val)
	// {
	// this.header= val;
	// }
	// Getter for enterprizeNum
	// public long getEnterprizeNum()
	// {
	// return enterprizeNum ;
	// }

	// Setter for enterprizeNum
	// public void setEnterprizeNum(long val)
	// {
	// this.enterprizeNum= val;
	// }
	// Getter for options
	// public ArrayList<DhcpOptionFactory.DhcpOption> getOptions()
	// {
	// return options ;
	// }

	// Setter for options
	// public void setOptions(ArrayList<DhcpOptionFactory.DhcpOption> val)
	// {
	// this.options= val;
	// }

	public int addToOptions(DhcpOptionFactory.DhcpOption val) {
		options.add(val);
		return options.size();
	}

	public int removeFromOptions(DhcpOptionFactory.DhcpOption val) {
		options.remove(val);
		return options.size();
	}

	public int removeNthFromOptions(int idx) {
		options.remove(idx);
		return options.size();
	}

	public int emptyOptions(int idx) {
		options.clear();
		return options.size();
	}

	public int getSize() throws IOException {
		DataOutputStream dos = new DataOutputStream(new NullStream());
		return this.write(dos);
	}

	public void setHeader(DhcpOptionHeader header) {
		this.header = header;
	}

	public DhcpOptionHeader getHeader() {
		return this.header;
	}

}

// End of code