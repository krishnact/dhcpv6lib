// Copyright (2013) Krishna C Tripathi. All rights reserved.
// 
// You are not allowed to read/copy/distribute following code without explicit written authorization from Krishna C Tripathi
//
package org.himalay.dhcpv6;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.lang.Exception;
import java.io.ByteArrayInputStream;
import java.io.PrintStream;
import org.himalay.msgs.runtime.Created;

import org.himalay.msgs.runtime.*;

@Created(date = "Thu Nov 06 01:18:25 EST 2014")
public class UserClass extends DhcpOptionFactory.DhcpOption { // Concrete type
																// is UserClass

	// members variables
	// header
	public DhcpOptionHeader header;
	// userClassData
	public ArrayList<OpaqueData> userClassData;

	public UserClass() // throws Exception
	{
		init();
	}

	private void init() {
		// Initialize header
		header = new DhcpOptionHeader();
		// Initialize userClassData
		userClassData = new ArrayList<OpaqueData>();
		userClassData.setMemberSize(0);
	}

	public int readNoHeader(DataInputStream istream) throws IOException {

		preRead();
		int retVal = 0;
		// read userClassData
		{
			int ilimit = retVal + (getHeader().length + (0));
			for (; retVal < ilimit;) {
				OpaqueData temp;
				temp = new OpaqueData();
				retVal += temp.read(istream);
				userClassData.add(temp);
			}
		}

		postRead();
		return retVal;
	}

	public int read(DataInputStream istream) throws IOException {
		preRead();
		int retVal = 0;

		// read header
		retVal += header.read(istream);
		// read userClassData
		{
			int ilimit = retVal + (getHeader().length + (0));
			for (; retVal < ilimit;) {
				OpaqueData temp;
				temp = new OpaqueData();
				retVal += temp.read(istream);
				userClassData.add(temp);
			}
		}

		postRead();
		return retVal;
	}

	public int write(DataOutputStream ostream) throws IOException {
		preWrite();
		int retVal = 0;

		{
			/** fix dependent sizes for header **/
		}
		{
			/** fix dependent sizes for userClassData **/
			header.length = ((short) userClassData.getSize() + (0));
		}

		// write header
		if (header != null)
			retVal += header.write(ostream);
		// write userClassData
		{
			ArrayList<OpaqueData> temp1 = userClassData;
			for (int iIdx = 0; iIdx < temp1.getCount(); iIdx++) {
				OpaqueData temp2 = temp1.get(iIdx);
				if (temp2 != null)
					retVal += temp2.write(ostream);
			}
		}
		postWrite();
		return retVal;
	}

	public int dump(DumpContext dc) throws IOException {
		dc.indent();
		dc.getPs().print("UserClass\n");
		dc.increaseIndent();
		int retVal = 0;
		// write header
		if (header != null) {
			dc.indent();
			dc.getPs().println("header");
			retVal += header.dump(dc);
		}
		// write userClassData
		{
			ArrayList<OpaqueData> temp1 = userClassData;
			for (int iIdx = 0; iIdx < temp1.getCount(); iIdx++) {
				OpaqueData element = temp1.get(iIdx);
				dc.indent();
				dc.getPs().println(iIdx);
				if (element != null) {
					dc.indent();
					dc.getPs().println("element");
					retVal += element.dump(dc);
				}
			}
		}
		dc.decreaseIndent();
		return retVal;
	}

	// Getter for header
	// public DhcpOptionHeader getHeader()
	// {
	// return header ;
	// }

	// Setter for header
	// public void setHeader(DhcpOptionHeader val)
	// {
	// this.header= val;
	// }
	// Getter for userClassData
	// public ArrayList<OpaqueData> getUserClassData()
	// {
	// return userClassData ;
	// }

	// Setter for userClassData
	// public void setUserClassData(ArrayList<OpaqueData> val)
	// {
	// this.userClassData= val;
	// }

	public int addToUserClassData(OpaqueData val) {
		userClassData.add(val);
		return userClassData.size();
	}

	public int removeFromUserClassData(OpaqueData val) {
		userClassData.remove(val);
		return userClassData.size();
	}

	public int removeNthFromUserClassData(int idx) {
		userClassData.remove(idx);
		return userClassData.size();
	}

	public int emptyUserClassData(int idx) {
		userClassData.clear();
		return userClassData.size();
	}

	public int getSize() throws IOException {
		DataOutputStream dos = new DataOutputStream(new NullStream());
		return this.write(dos);
	}

	public void setHeader(DhcpOptionHeader header) {
		this.header = header;
	}

	public DhcpOptionHeader getHeader() {
		return this.header;
	}

}

// End of code